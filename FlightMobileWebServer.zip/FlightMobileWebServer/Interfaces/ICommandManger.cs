﻿using FlightMobileApp.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using static FlightMobileApp.Models.AsyncCommands;

namespace FlightMobileApp.Interfaces
{
	public interface ICommandManger
	{
		void Connect(string ip, int port);
		void Disconnect();
		//Task<Byte[]> GetSceenshot();
		Task<Result> Execute(Command cmd);
	}
}
