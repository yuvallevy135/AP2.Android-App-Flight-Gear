﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FlightMobileApp.Interfaces
{
	public interface ITelnetClient
	{
		void Connect(string ip, int port);
		void Disconnect();
		void Write(string command);
		string Read();
	}
}
