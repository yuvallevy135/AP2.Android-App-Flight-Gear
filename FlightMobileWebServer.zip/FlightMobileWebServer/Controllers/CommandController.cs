﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FlightMobileApp.Interfaces;
using FlightMobileApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FlightMobileApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommandController : ControllerBase
    {
        private readonly ICommandManger _commandManager;
        public CommandController(ICommandManger commandManger)
        {
            _commandManager= commandManger;
            System.Diagnostics.Debug.WriteLine("This is Command Controller constructor");
        }
        // POST: api/Command
        [HttpPost]
        public async Task<ActionResult<Command>> PostCommand([FromBody] Command command)
        {
            try
            {
               var status = await _commandManager.Execute(command);
                switch (status)
                {
                    case AsyncCommands.Result.Ok:
                        return Ok();
                    case AsyncCommands.Result.NotOk:
                        return NotFound();
                    default:
                        return Ok();
                }
                //return Ok(command);
            }
            catch (Exception e)
            {
                return NotFound(e.Message);
            }
        }


        //// GET: api/screenshot
        //[HttpGet]
        //public async Task<IActionResult> GetScreenshot()
        //{
        //    try
        //    {
        //        // Get the screenshot and return it as byte arr.
        //        Byte[] b = await _commandManager.GetSceenshot();
        //        return File(b, "image/jpeg");
        //    }
        //    catch(Exception e)
        //    {
        //        return NotFound(e.Message);
        //    }
        //}
    }
}
