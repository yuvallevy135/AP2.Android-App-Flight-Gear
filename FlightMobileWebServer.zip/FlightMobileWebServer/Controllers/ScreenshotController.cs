﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using FlightMobileApp.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace FlightMobileApp.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ScreenshotController : ControllerBase
    {
        private readonly ICommandManger _commandManager;
        private string ip;
        private int port;
        private string httpPort;

        private bool isConnected = false;

        public ScreenshotController(IConfiguration config, ICommandManger commandManager)
        {
            _commandManager = commandManager;
            ip = config.GetConnectionString("ip");
            string stringPort = config.GetConnectionString("port");
            port = int.Parse(stringPort);
            httpPort = config.GetConnectionString("httpPort");
            System.Diagnostics.Debug.WriteLine("This is Screenshot constructor");
        }
        // GET: api/screenshot
        [HttpGet]
        public async Task<IActionResult> GetScreenshot()
        {
            try
            {
                using var client = new HttpClient
                {
                    //set time out for the request
                    Timeout = TimeSpan.FromSeconds(10)
                };
                // Create the url to send to.
                string url = "http" + "://" + ip + ":" + httpPort + "/screenshot";
                Byte[] b = await client.GetByteArrayAsync(url);
                return File(b, "image/jpeg");
            }
            catch (Exception e)
            {
                return NotFound(e.Message);
            }
        }
    }
}
