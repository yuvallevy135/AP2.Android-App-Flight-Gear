﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace FlightMobileApp.Models
{
	public class Command
	{
		[JsonProperty("aileron")]
		[Required]
		[Range(-1.0000000001, 1, ErrorMessage = "{0} has to be between {1} to {2}")]
		public float Aileron { get; set; }
		
		[JsonProperty("rudder")]
		[Required]
		[Range(-1.0000000001, 1, ErrorMessage = "{0} has to be between {1} to {2}")]
		public float Rudder { get; set; }
		[JsonProperty("elevator")]
		[Required]
		[Range(-1.0000000001, 1, ErrorMessage = "{0} has to be between {1} to {2}")]

		public float Elevator { get; set; }
		
		[JsonProperty("throttle")]
		[Required]
		[Range(0, 1, ErrorMessage = "{0} has to be between {1} to {2}")]
		public float Throttle { get; set; }
	}
}
