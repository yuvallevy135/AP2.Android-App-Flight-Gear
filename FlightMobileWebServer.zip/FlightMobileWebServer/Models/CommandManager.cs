﻿using FlightMobileApp.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static FlightMobileApp.Models.AsyncCommands;

namespace FlightMobileApp.Models
{
	public class CommandManager : ICommandManger
	{
        private double INF = 0.0000000000001;

        private ITelnetClient telnetClient;
        private volatile bool stop = false;
        private string ip;
        private int port;
        private string httpPort;
        private readonly BlockingCollection<AsyncCommands> commandsQueue;
        Mutex m = new Mutex();
        public CommandManager(IConfiguration config)
        {
            System.Diagnostics.Debug.WriteLine("This is commandManager constructor");
            ip = config.GetConnectionString("ip");
            string stringPort = config.GetConnectionString("port");
            port = int.Parse(stringPort);
            httpPort = config.GetConnectionString("httpPort");
            commandsQueue = new BlockingCollection<AsyncCommands>();
            telnetClient = new MyTelnetClient();
            telnetClient.Connect(ip, port);
            Start();
        }
        public void Start()
        {
            Task.Factory.StartNew(ProcessCommands);
        }
        public void ProcessCommands()
        {
            Result throttle, aileron, elevator, rudder;
            //telnetClient.Connect(ip,port);
            foreach(AsyncCommands command in commandsQueue.GetConsumingEnumerable())
            {
                try
                {
                    throttle = SendValuesToSimulator("/controls/engines/current-engine/throttle", command.Command.Throttle);
                    aileron = SendValuesToSimulator("/controls/flight/aileron", command.Command.Aileron);
                    elevator = SendValuesToSimulator("/controls/flight/elevator", command.Command.Elevator);
                    rudder = SendValuesToSimulator("/controls/flight/rudder", command.Command.Rudder);

                    command.Completion.SetResult(SetMyResult(throttle, aileron, elevator, rudder));

                } catch (Exception ex)
                {
                    command.Completion.SetException(ex);
                }
            }
        }

        public Result SetMyResult(Result throttle, Result aileron, Result elevator, Result rudder)
        {
            if (throttle != Result.Ok || aileron != Result.Ok || elevator != Result.Ok || rudder != Result.Ok)
            {
                return Result.NotOk;
            }
            return Result.Ok;
        }
        // Create Set and Get commands and send them to the simulator.
        //public Result SendValuesToSimulator(string path, double val)
        //{
        //    string set = "set ";
        //    set += path;
        //    set += " ";
        //    set += val.ToString() + "\r\n";
        //    //string get = "get ";
        //    //get += path;
        //    //get += "\r\n";
        //    m.WaitOne();
        //    telnetClient.Write(set);
        //    //telnetClient.Write(get);

        //    // Get return value from simulator to make sure we got the same values.
        //    //string got = telnetClient.Read();
        //    //m.ReleaseMutex();
        //    //if (got == null)
        //    //{
        //    //    return Result.NotOk;
        //    //}
        //    //// Remove \n and \r
        //    //got = got.TrimEnd('\r', '\n');
        //    //float gotten = float.Parse(got);

        //    //// Check if the value we got and the one we sent are the same.
        //    //if (Math.Abs(gotten - val) < INF)
        //    //{
        //    //    return Result.Ok;
        //    //}
        //    //return Result.NotOk;
        //    return Result.Ok;
        //}
        public Result SendValuesToSimulator(string path, float val)
        {
            string set = "set ";
            set += path;
            set += " ";
            set += val.ToString() + "\r\n";
            string get = "get ";
            get += path;
            get += "\r\n";
            m.WaitOne();
            telnetClient.Write(set);
            telnetClient.Write(get);

            // Get return value from simulator to make sure we got the same values.
            string got = telnetClient.Read();
            m.ReleaseMutex();
            if (got == null)
            {
                return Result.NotOk;
            }
            // Remove \n and \r
            got = got.TrimEnd('\r', '\n');
            float gotten = float.Parse(got);

            // Check if the value we got and the one we sent are the same.
            if (Math.Abs(gotten - val) < INF || gotten == val)
            {
                return Result.Ok;
            }
            return Result.NotOk;
        }

        //public async Task<Byte[]> GetSceenshot()
        //{
        //    try
        //    {
        //        using var client = new HttpClient
        //        {
        //            //set time out for the request
        //            Timeout = TimeSpan.FromSeconds(10)
        //        };
        //        // Create the url to send to.
        //        string url = "http" + "://" + ip  + ":" + httpPort+ "/screenshot";
        //        var screenshot = await client.GetByteArrayAsync(url);
        //        return screenshot;
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine("problem" + e.Message);
        //        throw new ArgumentException(e.Message);
        //    }

        //}
        public void Connect(string ip, int port)
        {
            telnetClient.Connect(ip, port);
        }
        public Task<Result> Execute(Command cmd)
        {
            var asyncCommand = new AsyncCommands(cmd);
            commandsQueue.Add(asyncCommand);
            return asyncCommand.Task;
        }
        public void Disconnect()
        {
            //Status = "Disconnected";
            //stop = true;
            //telnetClient.Disconnect();
            //InitializeDashboard();
        }
    }
}
