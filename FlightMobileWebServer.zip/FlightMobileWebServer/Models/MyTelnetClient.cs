﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows;
using FlightMobileApp.Interfaces;

namespace FlightMobileApp.Models
{
	public class MyTelnetClient : ITelnetClient
	{
        private TcpClient client;
        private bool stillConnect = false;
        private bool telnetErrorFlag;
        private int timeout = 10000;
        Mutex mutex;
        public MyTelnetClient()
        {
            System.Diagnostics.Debug.WriteLine("This is TelNet constructor");
            mutex = new Mutex();
        }

        public void Connect(string ip, int port)
        {
            client = new TcpClient();
            client.ReceiveTimeout = timeout;
            // Sets the receive time out using the ReceiveTimeout public property.
            
            if (!stillConnect)
            {
                try
                {
                    client.Connect(ip, port);
                    // Connect with "data\n" like Paul said.
                    mutex.WaitOne();
                    byte[] read = Encoding.ASCII.GetBytes("data\n");
                    client.GetStream().Write(read, 0, read.Length);
                    byte[] buffer = new byte[1024];
                    stillConnect = true;
                    mutex.ReleaseMutex();

                }
                catch (Exception)
                {
                    Console.WriteLine("Couldn't connect to server");
                }
            }
        }

        public void Disconnect()
        {
            // Disconecting from the server.
            if (stillConnect)
            {
                stillConnect = false;
                client.Close();
            }
        }
        public string Read()
        {
            if (stillConnect)
            {
                client.ReceiveTimeout = timeout;
                byte[] buffer = new byte[1024];
                var receivedBytesCount = client.GetStream().Read(buffer, 0, buffer.Length);
                var receivedString = Encoding.ASCII.GetString(buffer, 0, receivedBytesCount);
                return receivedString;
            }
            return null;
        }
        public void Write(string command)
        {
            if (stillConnect)
            {
                try
                {
                    
                    mutex.WaitOne();
                    client.ReceiveTimeout = timeout;
                    byte[] buffer = new byte[1024];
                    var encoding = Encoding.ASCII;
                    NetworkStream stream = client.GetStream();
                    var bytesToSend = encoding.GetBytes(command);
                    stream.Write(bytesToSend, 0, bytesToSend.Length);
                    stream.Flush();

                    mutex.ReleaseMutex();
                    //Console.WriteLine(data);
                }
                catch (IOException)
                {
                    mutex.ReleaseMutex();
                    throw new Exception("Lost connection with the Simulator");
                    // Niv - what did u do here?
                    //(Application.Current as App).model.Err = "Server is not responding...";
                }
                //catch (InvalidOperationException)
                //{
                //    mutex.ReleaseMutex();
                //    Disconnect();
                //    if (telnetErrorFlag == false)
                //    {
                //        // Niv - what did u do here?
                //        //(Application.Current as App).model.Err = "Server ended communication";
                //    }
                //    telnetErrorFlag = true;
                //}
            }
        }
    }
}
